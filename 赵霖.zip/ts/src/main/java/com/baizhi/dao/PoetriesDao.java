package com.baizhi.dao;

import com.baizhi.entity.Poetries;

import java.util.List;

public interface PoetriesDao {
    public List<Poetries> findAll();
}
