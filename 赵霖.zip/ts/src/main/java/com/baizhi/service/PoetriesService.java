package com.baizhi.service;

import com.baizhi.entity.Poetries;

import java.util.List;

public interface PoetriesService {
    public List<Poetries> queryAll();
}
